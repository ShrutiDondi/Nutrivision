import React from 'react';
import { Header } from './components/Header';
import { Camera } from './components/Camera';
import { FoodEditCard } from './components/FoodEditCard';
import { FeedbackSystem } from './components/FeedbackSystem';
import { PortionAdjuster } from './components/PortionAdjuster';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { FoodConfirmationModal } from './components/FoodConfirmationModal';
import { ImageQualityAlert } from './components/ImageQualityAlert';
import { MixedDishIndicator } from './components/MixedDishIndicator';
import { useFoodAnalysis } from './hooks/useFoodAnalysis';
import { ArrowLeft, Camera as CameraIcon } from 'lucide-react';

function App() {
  const { 
    isLoading, 
    error, 
    warning,
    suggestions,
    result, 
    portionMultiplier, 
    showConfirmationModal,
    pendingResult,
    imageQualityIssues,
    sessionCorrections,
    setPortionMultiplier, 
    analyzeFood, 
    reset,
    handleFoodUpdate,
    handlePortionUpdate,
    handleFeedbackSubmit,
    handleFoodConfirmation,
    handleRetakePhoto,
    handleProceedWithLowQuality
  } = useFoodAnalysis();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {!result && !isLoading && !error && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-xl shadow-lg p-8 text-center mb-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CameraIcon className="h-8 w-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Get Started
              </h2>
              <p className="text-gray-600 mb-6">
                Take a photo or upload an image of your food to get instant nutritional analysis
              </p>
              <Camera onCapture={analyzeFood} isLoading={isLoading} />
            </div>
            
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600 font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">AI Food Recognition</h4>
                    <p className="text-sm text-gray-600">Identifies multiple foods in a single image</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600 font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">Detailed Nutrition</h4>
                    <p className="text-sm text-gray-600">Calories, macros, vitamins, and minerals</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600 font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">Portion Adjustment</h4>
                    <p className="text-sm text-gray-600">Customize serving sizes for accurate data</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600 font-bold">✓</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">Mobile Friendly</h4>
                    <p className="text-sm text-gray-600">Works great on all devices</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {isLoading && (
          <div className="max-w-md mx-auto">
            <LoadingSpinner stage="recognizing" />
          </div>
        )}

        {imageQualityIssues.length > 0 && (
          <div className="max-w-md mx-auto">
            <ImageQualityAlert
              issues={imageQualityIssues}
              onRetry={handleRetakePhoto}
              onProceedAnyway={handleProceedWithLowQuality}
            />
          </div>
        )}

        {error && (
          <div className="max-w-md mx-auto">
            <ErrorMessage message={error} onRetry={reset} />
          </div>
        )}

        {result && (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <button
                onClick={reset}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                Analyze Another Food
              </button>
              <div className="text-sm text-gray-500">
                {result.timestamp.toLocaleString()}
              </div>
            </div>

            <MixedDishIndicator
              isVisible={result.mixedDishMode || false}
              foodCount={result.foods.length}
            />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-white rounded-xl shadow-lg p-4">
                  <img
                    src={result.imageUrl}
                    alt="Analyzed food"
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                  <div className="text-center space-y-2">
                    <p className="text-sm text-gray-600">
                      Found {result.foods.length} food item{result.foods.length !== 1 ? 's' : ''}
                    </p>
                    {result.detectionQuality && (
                      <div className="flex items-center justify-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          result.detectionQuality === 'high' ? 'bg-green-500' :
                          result.detectionQuality === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                        }`}></div>
                        <span className="text-xs text-gray-500 capitalize">
                          {result.detectionQuality} confidence detection
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {result.foods.map((food) => (
                  <FoodEditCard
                    key={food.id}
                    food={food}
                    onFoodChange={(updatedFood) => handleFoodUpdate(food.id, updatedFood)}
                    onPortionChange={(amount, unit) => handlePortionUpdate(food.id, amount, unit)}
                    portionMultiplier={portionMultiplier}
                  />
                ))}
                
                {/* Feedback System */}
                <FeedbackSystem
                  scanId={result.id}
                  detectedFood={result.foods.map(f => f.name).join(', ')}
                  onFeedbackSubmit={handleFeedbackSubmit}
                />
              </div>

              <div className="space-y-6">

                <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
                  <h3 className="text-lg font-bold text-gray-800 mb-4">Summary</h3>
                  <div className="space-y-3">
                    {result.foods.map((food, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-700">{food.name}</span>
                        <span className="text-sm text-gray-600">
                          {Math.round(food.nutrition.calories * portionMultiplier)} cal
                        </span>
                      </div>
                    ))}
                    <div className="pt-3 border-t border-gray-200">
                      <div className="flex justify-between items-center font-semibold text-gray-800">
                        <span>Total Calories</span>
                        <span>
                          {Math.round(result.foods.reduce((sum, food) => sum + food.nutrition.calories, 0) * portionMultiplier)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Session Corrections Summary */}
                {sessionCorrections.size > 0 && (
                  <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                    <h4 className="font-medium text-blue-800 mb-2">Session Corrections</h4>
                    <div className="text-sm text-blue-700">
                      You've made {sessionCorrections.size} correction{sessionCorrections.size !== 1 ? 's' : ''} this session.
                      These help improve our AI accuracy!
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <FoodConfirmationModal
          isOpen={showConfirmationModal}
          onClose={() => {
            setShowConfirmationModal(false);
          }}
          detectedFoods={pendingResult?.foods || []}
          onConfirm={handleFoodConfirmation}
          warning={pendingResult?.warning}
          suggestions={pendingResult?.suggestions}
        />
      </main>
    </div>
  );
}

export default App;