import React, { useState } from 'react';
import { ThumbsUp, ThumbsDown, Flag, Camera, Sun, Focus, Send } from 'lucide-react';
import { FoodFeedback } from '../types';

interface FeedbackSystemProps {
  scanId: string;
  detectedFood: string;
  onFeedbackSubmit: (feedback: FoodFeedback) => void;
  className?: string;
}

export const FeedbackSystem: React.FC<FeedbackSystemProps> = ({
  scanId,
  detectedFood,
  onFeedbackSubmit,
  className = ''
}) => {
  const [feedback, setFeedback] = useState<'positive' | 'negative' | null>(null);
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportData, setReportData] = useState({
    correctedFood: '',
    lighting: 'good' as 'good' | 'poor' | 'glare',
    angle: 'good' as 'good' | 'poor' | 'obscured',
    focus: 'sharp' as 'sharp' | 'blurry',
    additionalNotes: ''
  });

  const handleFeedbackClick = (rating: 'positive' | 'negative') => {
    setFeedback(rating);
    
    if (rating === 'positive') {
      // Submit positive feedback immediately
      const feedbackData: FoodFeedback = {
        scanId,
        rating,
        originalFood: detectedFood,
        timestamp: new Date()
      };
      onFeedbackSubmit(feedbackData);
    } else {
      // Show report form for negative feedback
      setShowReportForm(true);
    }
  };

  const handleReportSubmit = () => {
    const feedbackData: FoodFeedback = {
      scanId,
      rating: 'negative',
      originalFood: detectedFood,
      correctedFood: reportData.correctedFood || undefined,
      imageConditions: {
        lighting: reportData.lighting,
        angle: reportData.angle,
        focus: reportData.focus
      },
      timestamp: new Date()
    };
    
    onFeedbackSubmit(feedbackData);
    setShowReportForm(false);
  };

  return (
    <div className={`bg-white rounded-lg border border-gray-200 p-4 ${className}`}>
      {!showReportForm ? (
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-700">
              Was this identification correct?
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => handleFeedbackClick('positive')}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                  feedback === 'positive'
                    ? 'bg-green-100 text-green-700 scale-105'
                    : 'bg-gray-100 hover:bg-green-50 text-gray-600 hover:text-green-600'
                }`}
              >
                <ThumbsUp className="h-4 w-4" />
                Yes
              </button>
              <button
                onClick={() => handleFeedbackClick('negative')}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                  feedback === 'negative'
                    ? 'bg-red-100 text-red-700 scale-105'
                    : 'bg-gray-100 hover:bg-red-50 text-gray-600 hover:text-red-600'
                }`}
              >
                <ThumbsDown className="h-4 w-4" />
                No
              </button>
            </div>
          </div>
          
          {feedback === 'positive' && (
            <div className="text-sm text-green-600 bg-green-50 p-2 rounded">
              Thanks for your feedback! This helps improve our AI.
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-600">
            <Flag className="h-4 w-4" />
            <span className="font-medium">Report Incorrect Identification</span>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              What should this be called?
            </label>
            <input
              type="text"
              value={reportData.correctedFood}
              onChange={(e) => setReportData(prev => ({ ...prev, correctedFood: e.target.value }))}
              placeholder="Enter correct food name..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Sun className="h-3 w-3 inline mr-1" />
                Lighting
              </label>
              <select
                value={reportData.lighting}
                onChange={(e) => setReportData(prev => ({ ...prev, lighting: e.target.value as any }))}
                className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
              >
                <option value="good">Good</option>
                <option value="poor">Too dark</option>
                <option value="glare">Too bright/glare</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Camera className="h-3 w-3 inline mr-1" />
                Angle
              </label>
              <select
                value={reportData.angle}
                onChange={(e) => setReportData(prev => ({ ...prev, angle: e.target.value as any }))}
                className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
              >
                <option value="good">Good angle</option>
                <option value="poor">Poor angle</option>
                <option value="obscured">Food obscured</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Focus className="h-3 w-3 inline mr-1" />
                Focus
              </label>
              <select
                value={reportData.focus}
                onChange={(e) => setReportData(prev => ({ ...prev, focus: e.target.value as any }))}
                className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
              >
                <option value="sharp">Sharp</option>
                <option value="blurry">Blurry</option>
              </select>
            </div>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => setShowReportForm(false)}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleReportSubmit}
              className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Send className="h-4 w-4" />
              Submit Report
            </button>
          </div>
        </div>
      )}
    </div>
  );
};