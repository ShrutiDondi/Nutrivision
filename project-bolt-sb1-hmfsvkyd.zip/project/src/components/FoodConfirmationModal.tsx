import React, { useState } from 'react';
import { FoodItem } from '../types';
import { X, AlertTriangle, Search, Check } from 'lucide-react';
import { getFoodSuggestions, searchFoodByName } from '../services/foodRecognition';

interface FoodConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  detectedFoods: FoodItem[];
  onConfirm: (correctedFoods: FoodItem[]) => void;
  warning?: string;
  suggestions?: string[];
}

export const FoodConfirmationModal: React.FC<FoodConfirmationModalProps> = ({
  isOpen,
  onClose,
  detectedFoods,
  onConfirm,
  warning,
  suggestions = []
}) => {
  const [correctedFoods, setCorrectedFoods] = useState<FoodItem[]>(detectedFoods);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<FoodItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleSearch = async (term: string) => {
    if (term.length < 2) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const response = await searchFoodByName(term);
      if (response.success && response.data) {
        setSearchResults(response.data);
      }
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleFoodSelection = (selectedFood: FoodItem, index: number) => {
    const updated = [...correctedFoods];
    updated[index] = { ...selectedFood, detectionMethod: 'user_corrected' };
    setCorrectedFoods(updated);
    setEditingIndex(null);
    setSearchTerm('');
    setSearchResults([]);
  };

  const handleSuggestionSelect = (suggestion: string, index: number) => {
    setSearchTerm(suggestion);
    handleSearch(suggestion);
    setEditingIndex(index);
  };

  const handleConfirm = () => {
    onConfirm(correctedFoods);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-6 w-6 text-amber-600" />
              <h2 className="text-xl font-bold text-gray-800">Confirm Food Detection</h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          {warning && (
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-amber-800 text-sm">{warning}</p>
            </div>
          )}
        </div>

        <div className="p-6">
          <p className="text-gray-600 mb-6">
            Please review and correct the detected foods if needed:
          </p>

          <div className="space-y-4">
            {correctedFoods.map((food, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <span className="font-medium text-gray-800">{food.name}</span>
                    <span className="text-sm text-gray-500">
                      {Math.round(food.confidence * 100)}% confident
                    </span>
                  </div>
                  <button
                    onClick={() => setEditingIndex(editingIndex === index ? null : index)}
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    {editingIndex === index ? 'Cancel' : 'Change'}
                  </button>
                </div>

                {food.confidence < 0.8 && suggestions.length > 0 && (
                  <div className="mb-3">
                    <p className="text-sm text-gray-600 mb-2">Suggested alternatives:</p>
                    <div className="flex flex-wrap gap-2">
                      {suggestions.slice(0, 3).map((suggestion, suggestionIndex) => (
                        <button
                          key={suggestionIndex}
                          onClick={() => handleSuggestionSelect(suggestion, index)}
                          className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-sm rounded-full transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {editingIndex === index && (
                  <div className="mt-3 border-t border-gray-200 pt-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search for the correct food..."
                        value={searchTerm}
                        onChange={(e) => {
                          setSearchTerm(e.target.value);
                          handleSearch(e.target.value);
                        }}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>

                    {isSearching && (
                      <div className="mt-2 text-center text-sm text-gray-500">
                        Searching...
                      </div>
                    )}

                    {searchResults.length > 0 && (
                      <div className="mt-2 max-h-40 overflow-y-auto border border-gray-200 rounded-lg">
                        {searchResults.map((result, resultIndex) => (
                          <button
                            key={resultIndex}
                            onClick={() => handleFoodSelection(result, index)}
                            className="w-full text-left px-3 py-2 hover:bg-gray-50 border-b border-gray-100 last:border-b-0 transition-colors"
                          >
                            <div className="font-medium text-gray-800">{result.name}</div>
                            <div className="text-sm text-gray-600">{result.category}</div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="flex gap-3 mt-8">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Check className="h-4 w-4" />
              Confirm & Continue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};