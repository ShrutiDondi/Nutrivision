import React, { useState, useEffect, useRef } from 'react';
import { FoodItem } from '../types';
import { Edit3, Search, ChevronDown, Check, X, Scale } from 'lucide-react';
import { searchFoodByName, getFoodSuggestions } from '../services/foodRecognition';

interface FoodEditCardProps {
  food: FoodItem;
  onFoodChange: (updatedFood: FoodItem) => void;
  onPortionChange: (amount: number, unit: string) => void;
  portionMultiplier: number;
}

export const FoodEditCard: React.FC<FoodEditCardProps> = ({
  food,
  onFoodChange,
  onPortionChange,
  portionMultiplier
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState(food.name);
  const [searchResults, setSearchResults] = useState<FoodItem[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [portionAmount, setPortionAmount] = useState(100);
  const [portionUnit, setPortionUnit] = useState('g');
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isEditing && searchTerm.length > 1) {
      const timeoutId = setTimeout(async () => {
        setIsSearching(true);
        try {
          const [searchResponse, suggestionsList] = await Promise.all([
            searchFoodByName(searchTerm),
            Promise.resolve(getFoodSuggestions(searchTerm))
          ]);
          
          if (searchResponse.success && searchResponse.data) {
            setSearchResults(searchResponse.data);
          }
          setSuggestions(suggestionsList);
          setShowDropdown(true);
        } catch (error) {
          console.error('Search failed:', error);
        } finally {
          setIsSearching(false);
        }
      }, 300);

      return () => clearTimeout(timeoutId);
    } else {
      setShowDropdown(false);
    }
  }, [searchTerm, isEditing]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleFoodSelection = (selectedFood: FoodItem) => {
    setSearchTerm(selectedFood.name);
    onFoodChange(selectedFood);
    setShowDropdown(false);
    setIsEditing(false);
  };

  const handleManualEntry = () => {
    if (searchTerm !== food.name) {
      // Create a new food item with the manual entry
      const updatedFood: FoodItem = {
        ...food,
        name: searchTerm,
        confidence: 1.0, // User confirmed
        detectionMethod: 'user_corrected'
      };
      onFoodChange(updatedFood);
    }
    setIsEditing(false);
    setShowDropdown(false);
  };

  const handlePortionUpdate = () => {
    const multiplier = portionUnit === 'g' ? portionAmount / 100 : 
                     portionUnit === 'cup' ? portionAmount * 0.8 :
                     portionAmount * 0.5; // pieces
    onPortionChange(portionAmount, portionUnit);
  };

  const portionUnits = [
    { value: 'g', label: 'grams' },
    { value: 'cup', label: 'cups' },
    { value: 'piece', label: 'pieces' }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 mr-4">
            {!isEditing ? (
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-gray-800">{food.name}</h3>
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-1 px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg text-sm font-medium transition-colors"
                >
                  <Edit3 className="h-3 w-3" />
                  Edit
                </button>
              </div>
            ) : (
              <div className="relative" ref={searchRef}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Search or type food name..."
                      autoFocus
                    />
                  </div>
                  <button
                    onClick={handleManualEntry}
                    className="px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                  >
                    <Check className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => {
                      setIsEditing(false);
                      setSearchTerm(food.name);
                      setShowDropdown(false);
                    }}
                    className="px-3 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                {showDropdown && (suggestions.length > 0 || searchResults.length > 0) && (
                  <div className="absolute z-10 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {suggestions.length > 0 && (
                      <div className="p-2 border-b border-gray-100">
                        <div className="text-xs font-semibold text-gray-500 mb-2">QUICK SUGGESTIONS</div>
                        {suggestions.slice(0, 4).map((suggestion, index) => (
                          <button
                            key={index}
                            onClick={() => {
                              setSearchTerm(suggestion);
                              handleManualEntry();
                            }}
                            className="w-full text-left px-3 py-2 hover:bg-blue-50 rounded text-sm transition-colors"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    )}
                    
                    {searchResults.length > 0 && (
                      <div className="p-2">
                        <div className="text-xs font-semibold text-gray-500 mb-2">SEARCH RESULTS</div>
                        {searchResults.map((result, index) => (
                          <button
                            key={index}
                            onClick={() => handleFoodSelection(result)}
                            className="w-full text-left px-3 py-2 hover:bg-gray-50 rounded transition-colors"
                          >
                            <div className="font-medium text-gray-800">{result.name}</div>
                            <div className="text-sm text-gray-600">{result.category}</div>
                          </button>
                        ))}
                      </div>
                    )}
                    
                    {isSearching && (
                      <div className="p-4 text-center text-sm text-gray-500">
                        Searching...
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-500">{Math.round(food.confidence * 100)}% confident</span>
            <div className={`w-2 h-2 rounded-full ${
              food.confidence > 0.8 ? 'bg-green-500' : 
              food.confidence > 0.6 ? 'bg-yellow-500' : 'bg-red-500'
            }`}></div>
          </div>
        </div>

        {/* Portion Size Adjuster */}
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <Scale className="h-4 w-4 text-gray-600" />
            <span className="text-sm font-medium text-gray-700">Portion Size</span>
          </div>
          <div className="flex items-center gap-3">
            <input
              type="number"
              value={portionAmount}
              onChange={(e) => setPortionAmount(Number(e.target.value))}
              onBlur={handlePortionUpdate}
              className="w-20 px-3 py-1 border border-gray-300 rounded text-center"
              min="1"
              max="1000"
            />
            <select
              value={portionUnit}
              onChange={(e) => {
                setPortionUnit(e.target.value);
                handlePortionUpdate();
              }}
              className="px-3 py-1 border border-gray-300 rounded"
            >
              {portionUnits.map(unit => (
                <option key={unit.value} value={unit.value}>{unit.label}</option>
              ))}
            </select>
            <span className="text-sm text-gray-600">
              (≈ {portionMultiplier.toFixed(1)}x standard serving)
            </span>
          </div>
        </div>

        {/* Animated Nutrition Display */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 transition-all duration-300 ease-in-out">
          {[
            { name: 'Calories', value: Math.round(food.nutrition.calories * portionMultiplier), unit: 'kcal', color: 'text-orange-600' },
            { name: 'Protein', value: Math.round(food.nutrition.protein * portionMultiplier * 10) / 10, unit: 'g', color: 'text-red-600' },
            { name: 'Carbs', value: Math.round(food.nutrition.carbs * portionMultiplier * 10) / 10, unit: 'g', color: 'text-yellow-600' },
            { name: 'Fat', value: Math.round(food.nutrition.fat * portionMultiplier * 10) / 10, unit: 'g', color: 'text-blue-600' },
          ].map(({ name, value, unit, color }) => (
            <div key={name} className="text-center p-3 bg-gray-50 rounded-lg transform transition-all duration-200 hover:scale-105">
              <div className={`text-lg font-bold ${color} transition-all duration-300`}>
                {value}
              </div>
              <div className="text-xs text-gray-600">{unit}</div>
              <div className="text-xs text-gray-500 mt-1">{name}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};