import React from 'react';
import { Camera, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 bg-white bg-opacity-20 rounded-full">
            <Camera className="h-8 w-8" />
          </div>
          <h1 className="text-3xl font-bold">NutriVision</h1>
          <Sparkles className="h-6 w-6" />
        </div>
        <p className="text-center text-blue-100 max-w-2xl mx-auto">
          Instantly analyze your food with AI-powered recognition and get detailed nutritional information
        </p>
      </div>
    </header>
  );
};