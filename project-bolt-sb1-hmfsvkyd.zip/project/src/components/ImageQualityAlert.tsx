import React from 'react';
import { AlertTriangle, Camera, Sun, Focus } from 'lucide-react';

interface ImageQualityAlertProps {
  issues: string[];
  onRetry: () => void;
  onProceedAnyway: () => void;
}

export const ImageQualityAlert: React.FC<ImageQualityAlertProps> = ({
  issues,
  onRetry,
  onProceedAnyway
}) => {
  const getIssueIcon = (issue: string) => {
    if (issue.includes('blurry')) return <Focus className="h-5 w-5 text-amber-600" />;
    if (issue.includes('glare')) return <Sun className="h-5 w-5 text-amber-600" />;
    return <Camera className="h-5 w-5 text-amber-600" />;
  };

  return (
    <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 max-w-md mx-auto">
      <div className="flex items-center gap-3 mb-4">
        <AlertTriangle className="h-6 w-6 text-amber-600" />
        <h3 className="text-lg font-semibold text-amber-800">Image Quality Issues</h3>
      </div>
      
      <p className="text-amber-700 mb-4">
        We detected some issues that might affect food recognition accuracy:
      </p>
      
      <div className="space-y-3 mb-6">
        {issues.map((issue, index) => (
          <div key={index} className="flex items-start gap-3">
            {getIssueIcon(issue)}
            <span className="text-amber-700 text-sm">{issue}</span>
          </div>
        ))}
      </div>
      
      <div className="space-y-3">
        <button
          onClick={onRetry}
          className="w-full bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
        >
          Take Another Photo
        </button>
        <button
          onClick={onProceedAnyway}
          className="w-full border border-amber-300 text-amber-700 hover:bg-amber-100 px-4 py-2 rounded-lg font-medium transition-colors"
        >
          Proceed Anyway
        </button>
      </div>
    </div>
  );
};