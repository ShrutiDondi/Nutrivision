import React from 'react';
import { Loader2, Eye, Brain, Database } from 'lucide-react';

interface LoadingSpinnerProps {
  stage: 'analyzing' | 'recognizing' | 'fetching';
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ stage }) => {
  const stages = {
    analyzing: { icon: Eye, text: 'Analyzing image...', color: 'text-blue-600' },
    recognizing: { icon: Brain, text: 'Recognizing foods...', color: 'text-purple-600' },
    fetching: { icon: Database, text: 'Fetching nutrition data...', color: 'text-green-600' }
  };

  const currentStage = stages[stage];
  const Icon = currentStage.icon;

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-white rounded-xl shadow-lg border border-gray-100">
      <div className="relative mb-4">
        <Loader2 className="h-12 w-12 animate-spin text-gray-300" />
        <Icon className={`h-6 w-6 ${currentStage.color} absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2`} />
      </div>
      <p className="text-gray-600 font-medium">{currentStage.text}</p>
      <p className="text-sm text-gray-500 mt-2">This may take a few moments</p>
    </div>
  );
};