import React from 'react';
import { Utensils, Info } from 'lucide-react';

interface MixedDishIndicatorProps {
  isVisible: boolean;
  foodCount: number;
}

export const MixedDishIndicator: React.FC<MixedDishIndicatorProps> = ({
  isVisible,
  foodCount
}) => {
  if (!isVisible) return null;

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
      <div className="flex items-start gap-3">
        <Utensils className="h-5 w-5 text-blue-600 mt-0.5" />
        <div>
          <h4 className="font-medium text-blue-800 mb-1">Mixed Dish Detected</h4>
          <p className="text-blue-700 text-sm mb-2">
            We found {foodCount} different ingredients in your dish. Each item is analyzed separately for more accurate nutrition data.
          </p>
          <div className="flex items-center gap-2 text-xs text-blue-600">
            <Info className="h-3 w-3" />
            <span>Nutrition values are calculated per ingredient</span>
          </div>
        </div>
      </div>
    </div>
  );
};