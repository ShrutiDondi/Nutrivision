import React from 'react';
import { FoodItem } from '../types';
import { Zap, Beef, Wheat, Droplets, Apple, Sparkles } from 'lucide-react';

interface NutritionCardProps {
  food: FoodItem;
  portionMultiplier: number;
}

export const NutritionCard: React.FC<NutritionCardProps> = ({ food, portionMultiplier }) => {
  const nutrition = food.nutrition;
  
  const macros = [
    { name: 'Calories', value: Math.round(nutrition.calories * portionMultiplier), unit: 'kcal', icon: Zap, color: 'text-orange-600' },
    { name: 'Protein', value: Math.round(nutrition.protein * portionMultiplier * 10) / 10, unit: 'g', icon: Beef, color: 'text-red-600' },
    { name: 'Carbs', value: Math.round(nutrition.carbs * portionMultiplier * 10) / 10, unit: 'g', icon: Wheat, color: 'text-yellow-600' },
    { name: 'Fat', value: Math.round(nutrition.fat * portionMultiplier * 10) / 10, unit: 'g', icon: Droplets, color: 'text-blue-600' },
  ];

  const details = [
    { name: 'Fiber', value: Math.round(nutrition.fiber * portionMultiplier * 10) / 10, unit: 'g' },
    { name: 'Sugar', value: Math.round(nutrition.sugar * portionMultiplier * 10) / 10, unit: 'g' },
    { name: 'Sodium', value: Math.round(nutrition.sodium * portionMultiplier), unit: 'mg' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-800">{food.name}</h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">{Math.round(food.confidence * 100)}% confident</span>
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {macros.map(({ name, value, unit, icon: Icon, color }) => (
          <div key={name} className="text-center p-3 bg-gray-50 rounded-lg">
            <Icon className={`h-5 w-5 ${color} mx-auto mb-1`} />
            <div className="text-lg font-bold text-gray-800">{value}</div>
            <div className="text-xs text-gray-600">{unit}</div>
            <div className="text-xs text-gray-500 mt-1">{name}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {details.map(({ name, value, unit }) => (
          <div key={name} className="text-center">
            <div className="text-sm font-semibold text-gray-800">{value}{unit}</div>
            <div className="text-xs text-gray-600">{name}</div>
          </div>
        ))}
      </div>

      {nutrition.vitamins.length > 0 && (
        <div className="mb-4">
          <h4 className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
            <Apple className="h-4 w-4" />
            Vitamins
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {nutrition.vitamins.map((vitamin, index) => (
              <div key={index} className="flex justify-between text-xs">
                <span className="text-gray-600">{vitamin.name}</span>
                <span className="text-gray-800 font-medium">
                  {Math.round(vitamin.amount * portionMultiplier * 10) / 10}{vitamin.unit} ({vitamin.dailyValue}% DV)
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {nutrition.minerals.length > 0 && (
        <div>
          <h4 className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
            <Sparkles className="h-4 w-4" />
            Minerals
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {nutrition.minerals.map((mineral, index) => (
              <div key={index} className="flex justify-between text-xs">
                <span className="text-gray-600">{mineral.name}</span>
                <span className="text-gray-800 font-medium">
                  {Math.round(mineral.amount * portionMultiplier * 10) / 10}{mineral.unit} ({mineral.dailyValue}% DV)
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};