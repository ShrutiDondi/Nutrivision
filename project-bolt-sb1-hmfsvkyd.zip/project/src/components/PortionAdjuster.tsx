import React from 'react';
import { Minus, Plus, Scale } from 'lucide-react';

interface PortionAdjusterProps {
  multiplier: number;
  onMultiplierChange: (multiplier: number) => void;
}

export const PortionAdjuster: React.FC<PortionAdjusterProps> = ({ multiplier, onMultiplierChange }) => {
  const adjustPortion = (delta: number) => {
    const newMultiplier = Math.max(0.1, Math.min(5, multiplier + delta));
    onMultiplierChange(Math.round(newMultiplier * 10) / 10);
  };

  const getPortionText = () => {
    if (multiplier === 1) return 'Standard portion';
    if (multiplier < 1) return `${Math.round(multiplier * 100)}% of standard`;
    return `${Math.round(multiplier * 100)}% of standard`;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <h3 className="flex items-center gap-2 text-lg font-bold text-gray-800 mb-4">
        <Scale className="h-5 w-5" />
        Adjust Portion Size
      </h3>
      
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => adjustPortion(-0.1)}
          className="bg-gray-100 hover:bg-gray-200 text-gray-700 p-2 rounded-lg transition-colors"
        >
          <Minus className="h-4 w-4" />
        </button>
        
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-800">{multiplier}x</div>
          <div className="text-sm text-gray-600">{getPortionText()}</div>
        </div>
        
        <button
          onClick={() => adjustPortion(0.1)}
          className="bg-gray-100 hover:bg-gray-200 text-gray-700 p-2 rounded-lg transition-colors"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Quick adjustments:</span>
        </div>
        <div className="flex gap-2">
          {[0.5, 1, 1.5, 2].map((value) => (
            <button
              key={value}
              onClick={() => onMultiplierChange(value)}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                multiplier === value
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              {value}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};