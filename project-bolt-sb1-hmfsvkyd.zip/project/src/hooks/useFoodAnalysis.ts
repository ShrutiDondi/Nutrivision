import { useState, useCallback } from 'react';
import { FoodItem, ScanResult, UserCorrection, FoodFeedback } from '../types';
import { recognizeFood, submitUserCorrection, submitFeedback } from '../services/foodRecognition';

export const useFoodAnalysis = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [portionMultiplier, setPortionMultiplier] = useState(1);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [pendingResult, setPendingResult] = useState<{
    imageUrl: string;
    foods: FoodItem[];
    warning?: string;
    suggestions?: string[];
  } | null>(null);
  const [imageQualityIssues, setImageQualityIssues] = useState<string[]>([]);
  const [sessionCorrections, setSessionCorrections] = useState<Map<string, FoodItem>>(new Map());

  const analyzeFood = useCallback(async (imageFile: File) => {
    setIsLoading(true);
    setError(null);
    setWarning(null);
    setSuggestions([]);
    setImageQualityIssues([]);
    
    try {
      // Create preview URL
      const imageUrl = URL.createObjectURL(imageFile);
      
      // Simulate different stages of processing
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Recognize food
      const response = await recognizeFood(imageFile);
      
      if (!response.success) {
        if (response.warning && response.suggestions) {
          // Image quality issues
          setImageQualityIssues(response.suggestions);
          setError(response.error || 'Image quality issues detected');
        } else {
          setError(response.error || 'Failed to recognize food items');
        }
        return;
      }
      
      if (response.data) {
        // Check if user confirmation is needed
        const needsConfirmation = response.warning || response.suggestions?.length;
        
        if (needsConfirmation) {
          setPendingResult({
            imageUrl,
            foods: response.data,
            warning: response.warning,
            suggestions: response.suggestions
          });
          setShowConfirmationModal(true);
          return;
        }
        
        // Direct success - create scan result
        createScanResult(imageUrl, response.data);
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createScanResult = useCallback((imageUrl: string, foods: FoodItem[]) => {
    const mixedDishMode = foods.length > 1 || foods.some(f => f.category === 'Mixed Dish');
    const avgConfidence = foods.reduce((sum, f) => sum + f.confidence, 0) / foods.length;
    
    let detectionQuality: 'high' | 'medium' | 'low' = 'high';
    if (avgConfidence < 0.6) detectionQuality = 'low';
    else if (avgConfidence < 0.8) detectionQuality = 'medium';
    
    const scanResult: ScanResult = {
      id: Date.now().toString(),
      imageUrl,
      foods,
      timestamp: new Date(),
      portionMultiplier: 1,
      detectionQuality,
      mixedDishMode
    };
    
    setResult(scanResult);
    setPortionMultiplier(1);
  }, []);

  const handleFoodUpdate = useCallback((foodId: string, updatedFood: FoodItem) => {
    if (!result) return;
    
    // Update the food in the current result
    const updatedFoods = result.foods.map(food => 
      food.id === foodId ? updatedFood : food
    );
    
    setResult({
      ...result,
      foods: updatedFoods
    });
    
    // Store correction for this session
    setSessionCorrections(prev => new Map(prev.set(foodId, updatedFood)));
  }, [result]);

  const handlePortionUpdate = useCallback((foodId: string, amount: number, unit: string) => {
    // Calculate new multiplier based on portion
    const newMultiplier = unit === 'g' ? amount / 100 : 
                         unit === 'cup' ? amount * 0.8 :
                         amount * 0.5; // pieces
    setPortionMultiplier(newMultiplier);
  }, []);

  const handleFeedbackSubmit = useCallback((feedback: FoodFeedback) => {
    submitFeedback(feedback);
    
    // Update result with feedback
    if (result) {
      setResult({
        ...result,
        userFeedback: feedback.rating
      });
    }
  }, [result]);

  const handleFoodConfirmation = useCallback((correctedFoods: FoodItem[]) => {
    if (!pendingResult) return;
    
    // Save user corrections for learning
    correctedFoods.forEach((correctedFood, index) => {
      const originalFood = pendingResult.foods[index];
      if (originalFood && correctedFood.name !== originalFood.name) {
        const correction: UserCorrection = {
          originalFood: originalFood.name,
          correctedFood: correctedFood.name,
          imageHash: Date.now().toString(), // In production, use actual image hash
          timestamp: new Date()
        };
        submitUserCorrection(correction);
      }
    });
    
    createScanResult(pendingResult.imageUrl, correctedFoods);
    setShowConfirmationModal(false);
    setPendingResult(null);
  }, [pendingResult, createScanResult]);

  const handleRetakePhoto = useCallback(() => {
    setImageQualityIssues([]);
    setError(null);
    // This will trigger the camera component to reopen
  }, []);

  const handleProceedWithLowQuality = useCallback(async () => {
    setImageQualityIssues([]);
    setError(null);
    // In a real implementation, you'd retry with lower quality thresholds
    setError('Please try taking another photo for better results.');
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
    setWarning(null);
    setSuggestions([]);
    setImageQualityIssues([]);
    setShowConfirmationModal(false);
    setPendingResult(null);
    setPortionMultiplier(1);
    if (result?.imageUrl) {
      URL.revokeObjectURL(result.imageUrl);
    }
    if (pendingResult?.imageUrl) {
      URL.revokeObjectURL(pendingResult.imageUrl);
    }
  }, [result, pendingResult]);

  return {
    isLoading,
    error,
    warning,
    suggestions,
    result,
    portionMultiplier,
    showConfirmationModal,
    pendingResult,
    imageQualityIssues,
    sessionCorrections,
    setPortionMultiplier,
    analyzeFood,
    reset,
    handleFoodUpdate,
    handlePortionUpdate,
    handleFeedbackSubmit,
    handleFoodConfirmation,
    handleRetakePhoto,
    handleProceedWithLowQuality
  };
};