import { FoodItem, ApiResponse, DetectionResult, UserCorrection } from '../types';

// Enhanced mock food database with more diverse options
const mockFoodDatabase: FoodItem[] = [
  {
    id: '1',
    name: 'Grilled Chicken Breast',
    confidence: 0.95,
    category: 'Protein',
    servingSize: '100g',
    nutrition: {
      calories: 165,
      protein: 31,
      carbs: 0,
      fat: 3.6,
      fiber: 0,
      sugar: 0,
      sodium: 74,
      vitamins: [
        { name: 'Vitamin B6', amount: 0.5, unit: 'mg', dailyValue: 25 },
        { name: 'Niacin', amount: 8.5, unit: 'mg', dailyValue: 53 },
        { name: 'Vitamin B12', amount: 0.3, unit: 'mcg', dailyValue: 13 }
      ],
      minerals: [
        { name: 'Phosphorus', amount: 196, unit: 'mg', dailyValue: 20 },
        { name: 'Selenium', amount: 22, unit: 'mcg', dailyValue: 40 }
      ]
    },
    alternativeSuggestions: ['Chicken Thigh', 'Turkey Breast', 'Grilled Chicken Strips']
  },
  {
    id: '2',
    name: 'Brown Rice',
    confidence: 0.88,
    category: 'Grains',
    servingSize: '100g',
    nutrition: {
      calories: 111,
      protein: 2.6,
      carbs: 23,
      fat: 0.9,
      fiber: 1.8,
      sugar: 0.4,
      sodium: 5,
      vitamins: [
        { name: 'Thiamine', amount: 0.1, unit: 'mg', dailyValue: 8 },
        { name: 'Niacin', amount: 2.9, unit: 'mg', dailyValue: 18 }
      ],
      minerals: [
        { name: 'Magnesium', amount: 43, unit: 'mg', dailyValue: 10 },
        { name: 'Phosphorus', amount: 83, unit: 'mg', dailyValue: 8 }
      ]
    },
    alternativeSuggestions: ['White Rice', 'Jasmine Rice', 'Basmati Rice']
  },
  {
    id: '3',
    name: 'Steamed Broccoli',
    confidence: 0.92,
    category: 'Vegetables',
    servingSize: '100g',
    nutrition: {
      calories: 34,
      protein: 2.8,
      carbs: 7,
      fat: 0.4,
      fiber: 2.6,
      sugar: 1.5,
      sodium: 33,
      vitamins: [
        { name: 'Vitamin C', amount: 89, unit: 'mg', dailyValue: 99 },
        { name: 'Vitamin K', amount: 102, unit: 'mcg', dailyValue: 85 },
        { name: 'Folate', amount: 63, unit: 'mcg', dailyValue: 16 }
      ],
      minerals: [
        { name: 'Potassium', amount: 316, unit: 'mg', dailyValue: 9 },
        { name: 'Iron', amount: 0.7, unit: 'mg', dailyValue: 4 }
      ]
    },
    alternativeSuggestions: ['Raw Broccoli', 'Broccoli Florets', 'Roasted Broccoli']
  },
  {
    id: '4',
    name: 'Chicken Curry',
    confidence: 0.75,
    category: 'Mixed Dish',
    servingSize: '200g',
    nutrition: {
      calories: 245,
      protein: 22,
      carbs: 8,
      fat: 14,
      fiber: 2,
      sugar: 4,
      sodium: 680,
      vitamins: [
        { name: 'Vitamin A', amount: 120, unit: 'mcg', dailyValue: 13 },
        { name: 'Vitamin C', amount: 15, unit: 'mg', dailyValue: 17 }
      ],
      minerals: [
        { name: 'Iron', amount: 2.1, unit: 'mg', dailyValue: 12 },
        { name: 'Potassium', amount: 420, unit: 'mg', dailyValue: 12 }
      ]
    },
    alternativeSuggestions: ['Butter Chicken', 'Chicken Tikka Masala', 'Thai Chicken Curry']
  },
  {
    id: '5',
    name: 'Mixed Vegetable Stir Fry',
    confidence: 0.72,
    category: 'Mixed Dish',
    servingSize: '150g',
    nutrition: {
      calories: 85,
      protein: 3.2,
      carbs: 12,
      fat: 3.5,
      fiber: 4.1,
      sugar: 6,
      sodium: 320,
      vitamins: [
        { name: 'Vitamin C', amount: 45, unit: 'mg', dailyValue: 50 },
        { name: 'Vitamin K', amount: 78, unit: 'mcg', dailyValue: 65 }
      ],
      minerals: [
        { name: 'Potassium', amount: 285, unit: 'mg', dailyValue: 8 },
        { name: 'Iron', amount: 1.2, unit: 'mg', dailyValue: 7 }
      ]
    },
    alternativeSuggestions: ['Vegetable Medley', 'Asian Stir Fry', 'Sautéed Vegetables']
  },
  {
    id: '6',
    name: 'Biryani',
    confidence: 0.68,
    category: 'Mixed Dish',
    servingSize: '250g',
    nutrition: {
      calories: 290,
      protein: 12,
      carbs: 45,
      fat: 8,
      fiber: 2.5,
      sugar: 3,
      sodium: 750,
      vitamins: [
        { name: 'Thiamine', amount: 0.2, unit: 'mg', dailyValue: 17 },
        { name: 'Niacin', amount: 4.2, unit: 'mg', dailyValue: 26 }
      ],
      minerals: [
        { name: 'Iron', amount: 1.8, unit: 'mg', dailyValue: 10 },
        { name: 'Magnesium', amount: 35, unit: 'mg', dailyValue: 8 }
      ]
    },
    alternativeSuggestions: ['Chicken Biryani', 'Vegetable Biryani', 'Mutton Biryani', 'Pulao']
  }
];

// Store user corrections for learning
let userCorrections: UserCorrection[] = [];
let feedbackData: any[] = [];

// Simulate image quality analysis
const analyzeImageQuality = (imageFile: File): { quality: 'high' | 'medium' | 'low', issues: string[] } => {
  const issues: string[] = [];
  let quality: 'high' | 'medium' | 'low' = 'high';

  // Simulate various image quality checks
  const random = Math.random();
  
  if (random < 0.1) {
    issues.push('Image appears blurry - try holding the camera steady');
    quality = 'low';
  }
  
  if (random < 0.15) {
    issues.push('Too much glare detected - try adjusting lighting');
    quality = quality === 'low' ? 'low' : 'medium';
  }
  
  if (random < 0.08) {
    issues.push('Food is partially obscured - try a clearer angle');
    quality = 'low';
  }

  if (imageFile.size < 50000) {
    issues.push('Image resolution is too low - try taking a closer photo');
    quality = 'medium';
  }

  return { quality, issues };
};

// Enhanced multi-model food recognition
const performMultiModelRecognition = async (imageFile: File): Promise<DetectionResult> => {
  const imageQuality = analyzeImageQuality(imageFile);
  
  // Simulate primary model (Google Vision AI equivalent)
  const primaryResults = await simulatePrimaryModel(imageFile);
  
  // Simulate secondary model (CLIP equivalent) for cross-validation
  const secondaryResults = await simulateSecondaryModel(imageFile);
  
  // Cross-check results and determine confidence
  const finalResults = crossValidateResults(primaryResults, secondaryResults);
  
  // Determine if mixed dish mode should be activated
  const mixedDishDetected = detectMixedDish(finalResults);
  
  return {
    foods: finalResults,
    confidence: calculateOverallConfidence(finalResults),
    needsConfirmation: finalResults.some(food => food.confidence < 0.8),
    detectionQuality: imageQuality.quality,
    mixedDishDetected,
    imageQualityIssues: imageQuality.issues
  };
};

const simulatePrimaryModel = async (imageFile: File): Promise<FoodItem[]> => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Simulate more sophisticated recognition
  const numFoods = Math.random() < 0.3 ? Math.floor(Math.random() * 3) + 2 : 1;
  const results: FoodItem[] = [];
  
  for (let i = 0; i < numFoods; i++) {
    const randomFood = mockFoodDatabase[Math.floor(Math.random() * mockFoodDatabase.length)];
    const confidence = Math.random() * 0.4 + 0.6; // 0.6-1.0
    
    results.push({
      ...randomFood,
      confidence,
      detectionMethod: 'primary'
    });
  }
  
  return results;
};

const simulateSecondaryModel = async (imageFile: File): Promise<FoodItem[]> => {
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Secondary model with slightly different results
  const numFoods = Math.floor(Math.random() * 2) + 1;
  const results: FoodItem[] = [];
  
  for (let i = 0; i < numFoods; i++) {
    const randomFood = mockFoodDatabase[Math.floor(Math.random() * mockFoodDatabase.length)];
    const confidence = Math.random() * 0.3 + 0.65; // 0.65-0.95
    
    results.push({
      ...randomFood,
      confidence,
      detectionMethod: 'secondary'
    });
  }
  
  return results;
};

const crossValidateResults = (primary: FoodItem[], secondary: FoodItem[]): FoodItem[] => {
  const validated: FoodItem[] = [];
  
  // Check for matches between models
  primary.forEach(primaryFood => {
    const match = secondary.find(secondaryFood => 
      secondaryFood.name === primaryFood.name || 
      secondaryFood.category === primaryFood.category
    );
    
    if (match) {
      // Boost confidence for matched results
      validated.push({
        ...primaryFood,
        confidence: Math.min(0.98, (primaryFood.confidence + match.confidence) / 2 + 0.1)
      });
    } else {
      // Keep primary result but with original confidence
      validated.push(primaryFood);
    }
  });
  
  // Add unique secondary results with lower confidence
  secondary.forEach(secondaryFood => {
    const exists = validated.find(food => food.name === secondaryFood.name);
    if (!exists) {
      validated.push({
        ...secondaryFood,
        confidence: Math.max(0.5, secondaryFood.confidence - 0.1)
      });
    }
  });
  
  return validated.slice(0, 3); // Limit to 3 items max
};

const detectMixedDish = (foods: FoodItem[]): boolean => {
  // Detect if this looks like a mixed dish
  const hasMultipleCategories = new Set(foods.map(f => f.category)).size > 1;
  const hasMixedDishCategory = foods.some(f => f.category === 'Mixed Dish');
  const hasLowConfidenceItems = foods.some(f => f.confidence < 0.75);
  
  return hasMultipleCategories || hasMixedDishCategory || (foods.length > 1 && hasLowConfidenceItems);
};

const calculateOverallConfidence = (foods: FoodItem[]): number => {
  if (foods.length === 0) return 0;
  return foods.reduce((sum, food) => sum + food.confidence, 0) / foods.length;
};

export const recognizeFood = async (imageFile: File): Promise<ApiResponse<FoodItem[]>> => {
  try {
    const detectionResult = await performMultiModelRecognition(imageFile);
    
    // Check for low quality images
    if (detectionResult.imageQualityIssues && detectionResult.imageQualityIssues.length > 0) {
      return {
        success: false,
        error: "Image quality issues detected",
        warning: detectionResult.imageQualityIssues.join('. '),
        suggestions: ["Try retaking the photo with better lighting", "Hold the camera steady", "Get closer to the food"]
      };
    }
    
    // Check minimum confidence threshold
    const lowConfidenceItems = detectionResult.foods.filter(food => food.confidence < 0.8);
    
    if (lowConfidenceItems.length > 0 && detectionResult.confidence < 0.7) {
      return {
        success: true,
        data: detectionResult.foods,
        warning: `Low confidence detection. This might not be ${lowConfidenceItems[0].name}.`,
        suggestions: lowConfidenceItems[0].alternativeSuggestions || []
      };
    }
    
    return {
      success: true,
      data: detectionResult.foods
    };
    
  } catch (error) {
    return {
      success: false,
      error: 'Failed to analyze the image. Please try again with a clearer photo.'
    };
  }
};

export const searchFoodByName = async (name: string): Promise<ApiResponse<FoodItem[]>> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const results = mockFoodDatabase.filter(food => 
        food.name.toLowerCase().includes(name.toLowerCase()) ||
        food.alternativeSuggestions?.some(alt => alt.toLowerCase().includes(name.toLowerCase()))
      );
      
      resolve({
        success: true,
        data: results
      });
    }, 500);
  });
};

export const submitUserCorrection = (correction: UserCorrection): void => {
  userCorrections.push(correction);
  console.log('User correction saved:', correction);
  // In production, this would be sent to a backend service
};

export const submitFeedback = (feedback: any): void => {
  feedbackData.push(feedback);
  console.log('User feedback saved:', feedback);
  // In production, this would be sent to analytics/learning service
};

export const getFoodSuggestions = (partialName: string): string[] => {
  const suggestions = mockFoodDatabase
    .filter(food => food.name.toLowerCase().includes(partialName.toLowerCase()))
    .map(food => food.name)
    .slice(0, 5);
    
  // Add alternative suggestions
  mockFoodDatabase.forEach(food => {
    if (food.alternativeSuggestions) {
      food.alternativeSuggestions.forEach(alt => {
        if (alt.toLowerCase().includes(partialName.toLowerCase()) && !suggestions.includes(alt)) {
          suggestions.push(alt);
        }
      });
    }
  });
  
  return suggestions.slice(0, 8);
};