export interface FoodItem {
  id: string;
  name: string;
  confidence: number;
  category: string;
  servingSize: string;
  nutrition: NutritionInfo;
  alternativeSuggestions?: string[];
  detectionMethod?: 'primary' | 'secondary' | 'user_corrected';
}

export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  vitamins: VitaminInfo[];
  minerals: MineralInfo[];
}

export interface VitaminInfo {
  name: string;
  amount: number;
  unit: string;
  dailyValue: number;
}

export interface MineralInfo {
  name: string;
  amount: number;
  unit: string;
  dailyValue: number;
}

export interface ScanResult {
  id: string;
  imageUrl: string;
  foods: FoodItem[];
  timestamp: Date;
  portionMultiplier: number;
  needsUserConfirmation?: boolean;
  detectionQuality: 'high' | 'medium' | 'low';
  mixedDishMode?: boolean;
  userFeedback?: 'positive' | 'negative';
  userCorrections?: UserCorrection[];
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  warning?: string;
  suggestions?: string[];
}

export interface UserCorrection {
  originalFood: string;
  correctedFood: string;
  imageHash: string;
  timestamp: Date;
  portionSize?: string;
  portionAmount?: number;
  lightingConditions?: string;
  imageAngle?: string;
  confidence?: number;
}

export interface DetectionResult {
  foods: FoodItem[];
  confidence: number;
  needsConfirmation: boolean;
  detectionQuality: 'high' | 'medium' | 'low';
  mixedDishDetected: boolean;
  imageQualityIssues?: string[];
}

export interface FoodFeedback {
  scanId: string;
  rating: 'positive' | 'negative';
  originalFood: string;
  correctedFood?: string;
  imageConditions?: {
    lighting: 'good' | 'poor' | 'glare';
    angle: 'good' | 'poor' | 'obscured';
    focus: 'sharp' | 'blurry';
  };
  timestamp: Date;
}